open Front_end
open Ast
open Error

let hole () = failwith "TODO"

(* A function type is a pair where
 * the first element is the argument types
 * the second eleemnt is the return type *)
type ftyp = typ list * typ
[@@deriving show]

(* Function environment, aka Delta *)
type fenv = (string * ftyp) list
[@@deriving show]

(* Type environment, aka Gamma *)
type tenv = (string * typ) list
[@@deriving show]

(* Look up variable x in gamma, and raises an exception if x is not found *)
let lookup (x: string) (gamma: tenv) : typ =
  match List.assoc_opt x gamma with
  | Some v -> v
  | None -> unbound_var x
let insert x t gamma = (x,t) :: gamma
let print_tenv gamma = gamma |> show_tenv |> print_endline

(* Look up function f in delta, and raises an exception if f is not found *)
let lookup_f (f: string) (delta: fenv) : ftyp = 
  match List.assoc_opt f delta with
  | Some ftyp -> ftyp
  | None -> unbound_fn f
let print_fenv delta = delta |> show_fenv |> print_endline

(* Type check an expression *)
type result = tenv * typ
let rec check (e: expr) (delta: fenv) (gamma: tenv) : result =
  (* Helper function: return type t without changing the type environment *)
  let return (t: typ) : result = (gamma, t) in
  (* Helper function: type check e, but discard the new environment *)
  let type_of (e: expr) : typ = check e delta gamma |> snd in
  (* Helper function: type check a list of expressions *)
  let rec check_list (es: expr list) (gamma: tenv) : typ =
    match es with
    | [] -> empty_seq ()
    | [e] -> check e delta gamma |> snd
    | e::es' ->
      let gamma', te = check e delta gamma in
      expect e TUnit te;
      check_list es' gamma' in
  (* check starts here *)
  match e with
  | Const c -> 
    let t = match c with
    | CUnit -> TUnit
    | CBool _ -> TBool
    | CInt _ -> TInt in
    return t
  | Id x -> lookup x gamma |> return
  | Unary (Not, e) ->
    let te = type_of e in
    expect e TBool te;
    return TBool
  | Binary (op, e1, e2) ->
    let te1 = type_of e1 in
    let te2 = type_of e2 in
    (match kind_of_binop op with
    | Arith ->
      expect e1 TInt te1;
      expect e2 TInt te2;
      return TInt
    | Logic ->
      expect e1 TBool te1;
      expect e2 TBool te2;
      return TBool
    | EqNeq -> 
      assert_eq te1 te2 (msg_of_expr e1) (msg_of_expr e2);
      return TBool
    | Comp -> 
      expect e1 TInt te1;
      expect e2 TInt te2;
      return TBool)
  | Ite (ec, et, ef) ->
    let tc = type_of ec in
    let tt = type_of et in
    let tf = type_of ef in
    expect ec TBool tc;
    assert_eq tt tf (msg_of_expr et) (msg_of_expr ef);
    return tt
  | While (ec, ebody) ->
    let tc = type_of ec in
    let tbody = type_of ebody in
    expect ec TBool tc;
    expect ebody TUnit tbody;
    return TUnit
  | Let (x, t, e) ->
    let te = type_of e in
    expect_var x t te;
    (insert x t gamma, TUnit)
  | Assign (x, e) ->
    let t = lookup x gamma in
    let t' = type_of e in
    assert_eq t t' (msg_of_var x) (msg_of_expr e);
    return TUnit
  | Read (a, i) ->
    let t = lookup a gamma in
    let ti = type_of i in
    expect_var a TArr t;
    expect i TInt ti;
    return TInt
  | Write (a, i, e) ->
    let t = lookup a gamma in
    let ti = type_of i in
    let te = type_of e in
    expect_var a TArr t;
    expect i TInt ti;
    expect e TInt te;
    return TUnit
  | Seq es -> return (check_list es gamma)
  | Call (f, args) ->
    if f = "main" then
      main_called ();
    let t_param, t_return = lookup_f f delta in
    let enumerate xs = List.combine (List.init (List.length xs) (fun i -> i)) xs in
    let arg_t : (expr * typ) list = List.map (fun e -> (e, type_of e)) args in
    if List.length args <> List.length t_param then
      arg_length_mismatch f;
    List.iter (fun ((i, t), (e, t')) ->
      assert_eq t t' (msg_of_arg i) (msg_of_expr e))
      (List.combine (enumerate t_param) arg_t);
    return t_return


(* Look for a duplicated string in a list *)
let find_dup (ss: string list) : string option =
  let rec inner xs =
    match xs with
    | [] | [_] -> None
    | x1::x2::xs -> if x1 = x2 then Some x1 else inner (x2::xs)
  in inner (List.sort String.compare ss)

(* Type check a function *)
let check_fn (delta: fenv) ({name; param; body; return} : fn) : unit =
  let gamma = List.fold_left (fun gamma (x,t) -> (x,t) :: gamma) [] param in
  let xs = param |> List.map fst in
  let _, tbody = check body delta gamma in
  assert_eq return tbody (msg_of_return name) "body";
  match find_dup xs with
  | Some x -> duplicated_param name x
  | None -> ()

(* Patina's built-in functions *)
let built_in : fenv = [
  ("alloc", ([TInt], TArr));
  ("print_int", ([TInt], TUnit));
  ("print_bool", ([TBool], TUnit));
  ("print_arr", ([TArr; TInt], TUnit));
  ("print_ln", ([], TUnit));
]

(* Type check program *)
let check_prog (fns: prog) : unit =
  let delta =
    built_in @
    List.map (fun {name; param; return; _} -> 
      (name, (List.map snd param, return)))
      fns in
  let names = List.map fst delta in
  match find_dup names with
  | Some f -> duplicated_fn f
  | None -> ();
  match List.find_opt (fun {name; _} -> name = "main") fns with
  | None -> no_main ()
  | Some {param; return; _} ->
    if List.length param <> 0 then
      main_param ()
    else if return <> TUnit then
      main_return ()
    else ();
  List.iter (check_fn delta) fns
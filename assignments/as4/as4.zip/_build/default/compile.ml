open Front_end
open Arch

let hole () = failwith "BB TODO"
let bonus () = failwith "TODO (Bonus)"

(* Invariant: always store in rax the result of executing an expression *)
let res = rax

let label_counter = ref 0
let make_label n = "L" ^ string_of_int n
let new_label () =
  let n = !label_counter in
  label_counter := n + 1;
  make_label n

type stack_index = int
[@@deriving show]
(* Mapping from variables to their stack indices *)
type locals = (string * stack_index) list
[@@deriving show]
(* Compilation environment *)
type env = {top: stack_index; locals: locals}
[@@deriving show]
let insert x {top; locals} : env =
  {top = top + 1; locals = List.cons (x, top) locals}
let lookup x {locals; _} : stack_index = List.assoc x locals

let wordsize = 8 (* bytes *)

let rec compile (env: env) (e: Ast.expr) : env * prog =
  let imm_true = Imm 1 in
  let imm_unit = Imm 0 in
  let put_unit = mov imm_unit res in
  let recur e = compile env e |> snd in
  let return p = (env, p) in
  let read_var_at (i: stack_index) : prog =
    [mov (Mem (RBP, i * wordsize)) res] in
  let write_var_at (i: stack_index) : prog =
    [mov res (Mem (RBP, i * wordsize))] in
  (* print_endline "Locals:"; *)
  (* env.locals |> show_locals |> print_endline; *)
  match e with
  | Const c ->
    let n = match c with
    | CUnit ->  0
    | CBool b -> b |> Bool.to_int
    | CInt n -> n in
    return [ mov (Imm n) res ]
  | Unary (Not, e) ->
    recur e @ [not res] |> return
  | Binary (op, e1, e2) ->
    compile_binary recur op e1 e2 |> return
  | Ite (ec, et, ef) ->
    let true_branch = new_label () in
    let join_point = new_label () in
    recur ec @
    [ cmp imm_true res;
      jmp EQ true_branch] @
      recur ef @
    [ jmp_always join_point ] @
    [ Label true_branch ] @
    recur et @
    [ Label join_point ] |> return
  | While (ec, eb) ->
    let body = new_label () in
    let test = new_label () in
    [ jmp_always test ] @
    [ Label body ] @
    recur eb @
    [ Label test ] @
    recur ec @
    [ cmp imm_true res;
      jmp EQ body ] |> return
  | Let (x, _, e) ->
    let pe : prog =
      recur e @
      write_var_at env.top @
      [ put_unit ] in
    (insert x env, pe)
  | Id x ->
    lookup x env |> read_var_at |> return
  | Seq es -> compile_seq env es |> return

and compile_seq env = function
  | [] -> failwith "impossible"
  | [e] -> compile env e |> snd
  | e::es ->
    let env', p = compile env e in
    let p' = compile_seq env' es in
    p @ p'

and compile_binary recur op e1 e2 : prog =
  (* put result of e1 in rax, e2 in rbx *)
  let common =
    recur e1 @
    [ push res ] @
    recur e2 @
    [ mov res rbx ] @
    [ pop rax ] in
  match Ast.kind_of_binop op with
  | Arith ->
    common @
    (match op with
    | Add -> [add rbx rax]
    | Sub -> [sub rbx rax]
    | Mul -> [mul rbx rax]
    | _ -> failwith "arithop TODO")
  | _ -> failwith "op TODO"

let compile_expr (e: Ast.expr) : string =
  let p =
      [ push rbp ; mov rsp rbp ] @
    (compile {top = 1; locals = []} e |> snd) @
    [ mov rbp rsp ; pop rbp ; ret ]
     in
  String.concat "\n" ([
      ".text:";
      ".globl _patina_expr";
(*       ".type patina_expr, @function"; if you're compiling on macOS, comment out this line of code
 *)      "";
      "_patina_expr:"
    ] @
    List.map x86_of_asm p)

let compile_fn ({name; param; body; return} : Ast.fn) : prog =
    let initial = {top=8;locals=[]} in
  Label name ::
  (compile initial body |> snd) @
  [ ret ]

let compile_prog (fns: Ast.prog) : string =
  (* assume there's only a main function *)
  let main_fn = List.nth fns 0 in
  let prog = compile_fn main_fn in
  String.concat "\n" (List.map x86_of_asm prog)

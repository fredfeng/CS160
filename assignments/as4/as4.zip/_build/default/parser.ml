type token =
  | EOF
  | FUN
  | ARROWTO
  | COLON
  | COMMA
  | SEMICOLON
  | TUNIT
  | TBOOL
  | TINT
  | TARR
  | ALLOC
  | PRINT_INT
  | PRINT_BOOL
  | PRINT_ARR
  | PRINT_LN
  | LPAREN
  | RPAREN
  | LBRACKET
  | RBRACKET
  | LBRACE
  | RBRACE
  | ASSIGN
  | EQ
  | NEQ
  | GT
  | GEQ
  | LT
  | LEQ
  | TRUE
  | FALSE
  | AND
  | OR
  | NOT
  | LET
  | IF
  | THEN
  | ELSE
  | WHILE
  | PLUS
  | SUB
  | TIMES
  | DIV
  | UNIT
  | NUMBER of (int)
  | ID of (string)

open Parsing;;
let _ = parse_error;;
# 2 "parser.mly"
open Ast

(* Report a syntax error with the location of its orgin *)
let syntax_error () =
  let start_pos = Parsing.rhs_start_pos 1 in
  let end_pos = Parsing.rhs_end_pos 1 in
  raise (Error.SyntaxError {
    sl = start_pos.pos_lnum;
    sc = start_pos.pos_cnum - start_pos.pos_bol;
    el = end_pos.pos_lnum;
    ec = end_pos.pos_cnum - end_pos.pos_bol;
  })
# 64 "parser.ml"
let yytransl_const = [|
    0 (* EOF *);
  257 (* FUN *);
  258 (* ARROWTO *);
  259 (* COLON *);
  260 (* COMMA *);
  261 (* SEMICOLON *);
  262 (* TUNIT *);
  263 (* TBOOL *);
  264 (* TINT *);
  265 (* TARR *);
  266 (* ALLOC *);
  267 (* PRINT_INT *);
  268 (* PRINT_BOOL *);
  269 (* PRINT_ARR *);
  270 (* PRINT_LN *);
  271 (* LPAREN *);
  272 (* RPAREN *);
  273 (* LBRACKET *);
  274 (* RBRACKET *);
  275 (* LBRACE *);
  276 (* RBRACE *);
  277 (* ASSIGN *);
  278 (* EQ *);
  279 (* NEQ *);
  280 (* GT *);
  281 (* GEQ *);
  282 (* LT *);
  283 (* LEQ *);
  284 (* TRUE *);
  285 (* FALSE *);
  286 (* AND *);
  287 (* OR *);
  288 (* NOT *);
  289 (* LET *);
  290 (* IF *);
  291 (* THEN *);
  292 (* ELSE *);
  293 (* WHILE *);
  294 (* PLUS *);
  295 (* SUB *);
  296 (* TIMES *);
  297 (* DIV *);
  298 (* UNIT *);
    0|]

let yytransl_block = [|
  299 (* NUMBER *);
  300 (* ID *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\003\000\003\000\004\000\004\000\007\000\008\000\
\008\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\012\000\012\000\005\000\005\000\005\000\005\000\006\000\013\000\
\013\000\009\000\009\000\009\000\009\000\010\000\011\000\011\000\
\011\000\011\000\011\000\011\000\011\000\011\000\011\000\011\000\
\011\000\011\000\000\000\000\000"

let yylen = "\002\000\
\002\000\002\000\001\000\002\000\007\000\009\000\003\000\000\000\
\003\000\001\000\001\000\002\000\001\000\001\000\003\000\006\000\
\001\000\006\000\003\000\004\000\003\000\006\000\003\000\005\000\
\000\000\003\000\001\000\001\000\001\000\001\000\003\000\001\000\
\003\000\002\000\001\000\001\000\001\000\002\000\003\000\003\000\
\003\000\003\000\003\000\003\000\003\000\003\000\003\000\003\000\
\003\000\003\000\002\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\051\000\000\000\000\000\
\000\000\000\000\035\000\036\000\000\000\000\000\000\000\000\000\
\000\000\037\000\000\000\000\000\017\000\010\000\013\000\014\000\
\002\000\000\000\001\000\004\000\034\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\012\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\015\000\000\000\031\000\
\000\000\000\000\019\000\023\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\041\000\042\000\000\000\000\000\000\000\033\000\027\000\
\028\000\029\000\030\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\024\000\
\000\000\000\000\007\000\000\000\000\000\000\000\016\000\026\000\
\000\000\005\000\009\000\000\000\000\000\006\000"

let yydgoto = "\003\000\
\006\000\031\000\007\000\008\000\084\000\021\000\078\000\092\000\
\022\000\023\000\024\000\087\000\032\000"

let yysindex = "\018\000\
\054\255\116\255\000\000\006\000\221\254\000\000\025\000\026\255\
\245\254\116\255\000\000\000\000\116\255\242\254\116\255\116\255\
\116\255\000\000\251\254\251\000\000\000\000\000\000\000\000\000\
\000\000\037\255\000\000\000\000\000\000\140\255\077\255\036\255\
\227\255\058\255\188\255\217\255\000\000\095\255\116\255\116\255\
\116\255\116\255\116\255\116\255\116\255\116\255\116\255\116\255\
\116\255\116\255\116\255\116\255\243\254\000\000\116\255\000\000\
\059\255\043\255\000\000\000\000\047\255\168\255\251\000\081\255\
\081\255\081\255\081\255\081\255\081\255\227\255\227\255\018\255\
\018\255\000\000\000\000\061\255\073\255\075\255\000\000\000\000\
\000\000\000\000\000\000\062\255\044\255\116\255\074\255\068\255\
\059\255\059\255\048\255\078\255\116\255\043\255\047\255\000\000\
\116\255\043\255\000\000\075\255\091\255\251\000\000\000\000\000\
\251\000\000\000\000\000\059\255\043\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\096\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\001\000\097\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\086\255\000\000\
\105\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\082\255\000\000\225\000\113\000\
\133\000\141\000\161\000\169\000\189\000\197\000\217\000\057\000\
\081\000\000\000\000\000\000\000\000\000\093\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\029\000\
\000\000\000\000\000\000\000\000\000\000\000\000\082\255\000\000\
\000\000\000\000\000\000\093\255\000\000\235\000\000\000\000\000\
\245\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\254\255\104\000\000\000\201\255\222\255\034\000\026\000\
\000\000\000\000\000\000\035\000\082\000"

let yytablesize = 548
let yytable = "\020\000\
\011\000\059\000\076\000\009\000\029\000\025\000\030\000\010\000\
\026\000\038\000\033\000\039\000\035\000\036\000\037\000\040\000\
\011\000\012\000\001\000\002\000\013\000\014\000\015\000\085\000\
\027\000\016\000\005\000\017\000\020\000\034\000\077\000\018\000\
\019\000\098\000\099\000\061\000\062\000\063\000\064\000\065\000\
\066\000\067\000\068\000\069\000\070\000\071\000\072\000\073\000\
\074\000\075\000\086\000\053\000\109\000\004\000\005\000\056\000\
\039\000\051\000\052\000\103\000\057\000\010\000\089\000\106\000\
\080\000\081\000\082\000\083\000\041\000\042\000\043\000\044\000\
\045\000\046\000\110\000\090\000\047\000\048\000\091\000\094\000\
\040\000\055\000\093\000\095\000\049\000\050\000\051\000\052\000\
\097\000\096\000\102\000\077\000\108\000\101\000\105\000\003\000\
\052\000\025\000\041\000\042\000\043\000\044\000\045\000\046\000\
\038\000\032\000\047\000\048\000\008\000\009\000\060\000\028\000\
\043\000\010\000\049\000\050\000\051\000\052\000\049\000\050\000\
\051\000\052\000\011\000\012\000\100\000\107\000\013\000\014\000\
\015\000\104\000\009\000\016\000\044\000\017\000\010\000\000\000\
\079\000\018\000\019\000\000\000\045\000\000\000\000\000\011\000\
\012\000\000\000\000\000\013\000\014\000\015\000\000\000\000\000\
\016\000\000\000\017\000\054\000\000\000\000\000\018\000\019\000\
\046\000\041\000\042\000\043\000\044\000\045\000\046\000\000\000\
\047\000\047\000\048\000\000\000\000\000\000\000\000\000\000\000\
\000\000\049\000\050\000\051\000\052\000\000\000\000\000\000\000\
\000\000\088\000\000\000\000\000\048\000\041\000\042\000\043\000\
\044\000\045\000\046\000\000\000\049\000\047\000\048\000\000\000\
\000\000\000\000\000\000\000\000\000\000\049\000\050\000\051\000\
\052\000\041\000\042\000\043\000\044\000\045\000\046\000\000\000\
\050\000\047\000\048\000\000\000\000\000\000\000\058\000\000\000\
\021\000\049\000\050\000\051\000\052\000\000\000\000\000\000\000\
\000\000\000\000\018\000\010\000\000\000\000\000\041\000\042\000\
\043\000\044\000\045\000\046\000\022\000\000\000\047\000\048\000\
\041\000\042\000\043\000\044\000\045\000\046\000\049\000\050\000\
\051\000\052\000\000\000\000\000\011\000\011\000\000\000\000\000\
\049\000\050\000\051\000\052\000\000\000\000\000\000\000\000\000\
\011\000\000\000\011\000\011\000\011\000\000\000\011\000\011\000\
\011\000\011\000\011\000\011\000\000\000\000\000\011\000\011\000\
\020\000\020\000\000\000\011\000\000\000\000\000\011\000\011\000\
\011\000\011\000\000\000\000\000\020\000\000\000\020\000\020\000\
\020\000\000\000\020\000\020\000\020\000\020\000\020\000\020\000\
\000\000\000\000\020\000\020\000\039\000\039\000\000\000\020\000\
\000\000\000\000\020\000\020\000\020\000\020\000\000\000\000\000\
\039\000\000\000\039\000\039\000\039\000\000\000\039\000\039\000\
\039\000\039\000\039\000\039\000\040\000\040\000\039\000\039\000\
\000\000\000\000\000\000\039\000\000\000\000\000\039\000\039\000\
\040\000\000\000\040\000\040\000\040\000\000\000\040\000\040\000\
\040\000\040\000\040\000\040\000\038\000\038\000\040\000\040\000\
\000\000\000\000\000\000\040\000\043\000\043\000\040\000\040\000\
\038\000\000\000\038\000\038\000\038\000\000\000\000\000\000\000\
\043\000\000\000\043\000\043\000\043\000\000\000\038\000\038\000\
\044\000\044\000\000\000\038\000\000\000\000\000\043\000\043\000\
\045\000\045\000\000\000\043\000\044\000\000\000\044\000\044\000\
\044\000\000\000\000\000\000\000\045\000\000\000\045\000\045\000\
\045\000\000\000\044\000\044\000\046\000\046\000\000\000\044\000\
\000\000\000\000\045\000\045\000\047\000\047\000\000\000\045\000\
\046\000\000\000\046\000\046\000\046\000\000\000\000\000\000\000\
\047\000\000\000\047\000\047\000\047\000\000\000\046\000\046\000\
\048\000\048\000\000\000\046\000\000\000\000\000\047\000\047\000\
\049\000\049\000\000\000\047\000\048\000\000\000\048\000\048\000\
\048\000\000\000\000\000\000\000\049\000\000\000\049\000\049\000\
\049\000\000\000\048\000\048\000\050\000\050\000\000\000\048\000\
\000\000\000\000\049\000\049\000\021\000\021\000\000\000\049\000\
\050\000\000\000\050\000\050\000\050\000\000\000\018\000\018\000\
\021\000\000\000\021\000\021\000\021\000\000\000\050\000\050\000\
\022\000\022\000\018\000\050\000\018\000\018\000\018\000\000\000\
\000\000\000\000\000\000\021\000\022\000\000\000\022\000\022\000\
\022\000\000\000\000\000\000\000\000\000\018\000\000\000\000\000\
\041\000\042\000\043\000\044\000\045\000\046\000\000\000\022\000\
\047\000\048\000\000\000\000\000\000\000\000\000\000\000\000\000\
\049\000\050\000\051\000\052\000"

let yycheck = "\002\000\
\000\000\036\000\016\001\015\001\016\001\000\000\009\000\019\001\
\044\001\015\001\013\000\017\001\015\000\016\000\017\000\021\001\
\028\001\029\001\001\000\002\000\032\001\033\001\034\001\058\000\
\000\000\037\001\001\001\039\001\000\000\044\001\044\001\043\001\
\044\001\089\000\090\000\038\000\039\000\040\000\041\000\042\000\
\043\000\044\000\045\000\046\000\047\000\048\000\049\000\050\000\
\051\000\052\000\004\001\015\001\108\000\000\001\001\001\020\001\
\000\000\040\001\041\001\094\000\003\001\019\001\002\001\098\000\
\006\001\007\001\008\001\009\001\022\001\023\001\024\001\025\001\
\026\001\027\001\109\000\003\001\030\001\031\001\004\001\036\001\
\000\000\005\001\021\001\086\000\038\001\039\001\040\001\041\001\
\021\001\016\001\093\000\044\001\002\001\016\001\097\000\000\000\
\000\000\016\001\022\001\023\001\024\001\025\001\026\001\027\001\
\000\000\020\001\030\001\031\001\016\001\015\001\016\001\008\000\
\000\000\019\001\038\001\039\001\040\001\041\001\038\001\039\001\
\040\001\041\001\028\001\029\001\091\000\100\000\032\001\033\001\
\034\001\095\000\015\001\037\001\000\000\039\001\019\001\255\255\
\055\000\043\001\044\001\255\255\000\000\255\255\255\255\028\001\
\029\001\255\255\255\255\032\001\033\001\034\001\255\255\255\255\
\037\001\255\255\039\001\016\001\255\255\255\255\043\001\044\001\
\000\000\022\001\023\001\024\001\025\001\026\001\027\001\255\255\
\000\000\030\001\031\001\255\255\255\255\255\255\255\255\255\255\
\255\255\038\001\039\001\040\001\041\001\255\255\255\255\255\255\
\255\255\018\001\255\255\255\255\000\000\022\001\023\001\024\001\
\025\001\026\001\027\001\255\255\000\000\030\001\031\001\255\255\
\255\255\255\255\255\255\255\255\255\255\038\001\039\001\040\001\
\041\001\022\001\023\001\024\001\025\001\026\001\027\001\255\255\
\000\000\030\001\031\001\255\255\255\255\255\255\035\001\255\255\
\000\000\038\001\039\001\040\001\041\001\255\255\255\255\255\255\
\255\255\255\255\000\000\019\001\255\255\255\255\022\001\023\001\
\024\001\025\001\026\001\027\001\000\000\255\255\030\001\031\001\
\022\001\023\001\024\001\025\001\026\001\027\001\038\001\039\001\
\040\001\041\001\255\255\255\255\004\001\005\001\255\255\255\255\
\038\001\039\001\040\001\041\001\255\255\255\255\255\255\255\255\
\016\001\255\255\018\001\019\001\020\001\255\255\022\001\023\001\
\024\001\025\001\026\001\027\001\255\255\255\255\030\001\031\001\
\004\001\005\001\255\255\035\001\255\255\255\255\038\001\039\001\
\040\001\041\001\255\255\255\255\016\001\255\255\018\001\019\001\
\020\001\255\255\022\001\023\001\024\001\025\001\026\001\027\001\
\255\255\255\255\030\001\031\001\004\001\005\001\255\255\035\001\
\255\255\255\255\038\001\039\001\040\001\041\001\255\255\255\255\
\016\001\255\255\018\001\019\001\020\001\255\255\022\001\023\001\
\024\001\025\001\026\001\027\001\004\001\005\001\030\001\031\001\
\255\255\255\255\255\255\035\001\255\255\255\255\038\001\039\001\
\016\001\255\255\018\001\019\001\020\001\255\255\022\001\023\001\
\024\001\025\001\026\001\027\001\004\001\005\001\030\001\031\001\
\255\255\255\255\255\255\035\001\004\001\005\001\038\001\039\001\
\016\001\255\255\018\001\019\001\020\001\255\255\255\255\255\255\
\016\001\255\255\018\001\019\001\020\001\255\255\030\001\031\001\
\004\001\005\001\255\255\035\001\255\255\255\255\030\001\031\001\
\004\001\005\001\255\255\035\001\016\001\255\255\018\001\019\001\
\020\001\255\255\255\255\255\255\016\001\255\255\018\001\019\001\
\020\001\255\255\030\001\031\001\004\001\005\001\255\255\035\001\
\255\255\255\255\030\001\031\001\004\001\005\001\255\255\035\001\
\016\001\255\255\018\001\019\001\020\001\255\255\255\255\255\255\
\016\001\255\255\018\001\019\001\020\001\255\255\030\001\031\001\
\004\001\005\001\255\255\035\001\255\255\255\255\030\001\031\001\
\004\001\005\001\255\255\035\001\016\001\255\255\018\001\019\001\
\020\001\255\255\255\255\255\255\016\001\255\255\018\001\019\001\
\020\001\255\255\030\001\031\001\004\001\005\001\255\255\035\001\
\255\255\255\255\030\001\031\001\004\001\005\001\255\255\035\001\
\016\001\255\255\018\001\019\001\020\001\255\255\004\001\005\001\
\016\001\255\255\018\001\019\001\020\001\255\255\030\001\031\001\
\004\001\005\001\016\001\035\001\018\001\019\001\020\001\255\255\
\255\255\255\255\255\255\035\001\016\001\255\255\018\001\019\001\
\020\001\255\255\255\255\255\255\255\255\035\001\255\255\255\255\
\022\001\023\001\024\001\025\001\026\001\027\001\255\255\035\001\
\030\001\031\001\255\255\255\255\255\255\255\255\255\255\255\255\
\038\001\039\001\040\001\041\001"

let yynames_const = "\
  EOF\000\
  FUN\000\
  ARROWTO\000\
  COLON\000\
  COMMA\000\
  SEMICOLON\000\
  TUNIT\000\
  TBOOL\000\
  TINT\000\
  TARR\000\
  ALLOC\000\
  PRINT_INT\000\
  PRINT_BOOL\000\
  PRINT_ARR\000\
  PRINT_LN\000\
  LPAREN\000\
  RPAREN\000\
  LBRACKET\000\
  RBRACKET\000\
  LBRACE\000\
  RBRACE\000\
  ASSIGN\000\
  EQ\000\
  NEQ\000\
  GT\000\
  GEQ\000\
  LT\000\
  LEQ\000\
  TRUE\000\
  FALSE\000\
  AND\000\
  OR\000\
  NOT\000\
  LET\000\
  IF\000\
  THEN\000\
  ELSE\000\
  WHILE\000\
  PLUS\000\
  SUB\000\
  TIMES\000\
  DIV\000\
  UNIT\000\
  "

let yynames_block = "\
  NUMBER\000\
  ID\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'prog) in
    Obj.repr(
# 46 "parser.mly"
                                        ( _1 )
# 391 "parser.ml"
               : Ast.prog))
; (fun __caml_parser_env ->
    Obj.repr(
# 47 "parser.mly"
                                        ( syntax_error () )
# 397 "parser.ml"
               : Ast.prog))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'fundef) in
    Obj.repr(
# 49 "parser.mly"
                                        ( [_1] )
# 404 "parser.ml"
               : 'prog))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'fundef) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'prog) in
    Obj.repr(
# 50 "parser.mly"
                                        ( _1 :: _2 )
# 412 "parser.ml"
               : 'prog))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 5 : string) in
    let _6 = (Parsing.peek_val __caml_parser_env 1 : 'typ) in
    let _7 = (Parsing.peek_val __caml_parser_env 0 : 'seq) in
    Obj.repr(
# 53 "parser.mly"
                                        ( { name = _2; param = []; return = _6; body = _7 } )
# 421 "parser.ml"
               : 'fundef))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 7 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 5 : 'param) in
    let _5 = (Parsing.peek_val __caml_parser_env 4 : 'param_plus) in
    let _8 = (Parsing.peek_val __caml_parser_env 1 : 'typ) in
    let _9 = (Parsing.peek_val __caml_parser_env 0 : 'seq) in
    Obj.repr(
# 55 "parser.mly"
                                        ( { name = _2; param = _4::_5; return = _8; body = _9 } )
# 432 "parser.ml"
               : 'fundef))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'typ) in
    Obj.repr(
# 57 "parser.mly"
                                        ( (_1, _3) )
# 440 "parser.ml"
               : 'param))
; (fun __caml_parser_env ->
    Obj.repr(
# 59 "parser.mly"
                                        ( [] )
# 446 "parser.ml"
               : 'param_plus))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'param) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'param_plus) in
    Obj.repr(
# 60 "parser.mly"
                                        ( _2 :: _3 )
# 454 "parser.ml"
               : 'param_plus))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'const) in
    Obj.repr(
# 62 "parser.mly"
                                        ( Const _1 )
# 461 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 63 "parser.mly"
                                        ( Id(_1) )
# 468 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 65 "parser.mly"
                                        ( Binary(Sub, Const (CInt 0), _2) )
# 475 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'unop) in
    Obj.repr(
# 66 "parser.mly"
                                        ( _1 )
# 482 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'binop) in
    Obj.repr(
# 67 "parser.mly"
                                        ( _1 )
# 489 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Ast.expr) in
    Obj.repr(
# 68 "parser.mly"
                                        ( _2 )
# 496 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 4 : Ast.expr) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : 'seq) in
    let _6 = (Parsing.peek_val __caml_parser_env 0 : 'seq) in
    Obj.repr(
# 69 "parser.mly"
                                        ( Ite(_2, _4, _6) )
# 505 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'seq) in
    Obj.repr(
# 70 "parser.mly"
                                        ( _1 )
# 512 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 4 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : 'typ) in
    let _6 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 71 "parser.mly"
                                        ( Let(_2, _4, _6) )
# 521 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'seq) in
    Obj.repr(
# 72 "parser.mly"
                                        ( While(_2, _3) )
# 529 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : Ast.expr) in
    Obj.repr(
# 73 "parser.mly"
                                        ( Read(_1, _3) )
# 537 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 74 "parser.mly"
                                        ( Assign(_1, _3) )
# 545 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : Ast.expr) in
    let _6 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 76 "parser.mly"
                                        ( Write(_1, _3, _6) )
# 554 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    Obj.repr(
# 77 "parser.mly"
                                        ( Call(_1, []))
# 561 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expr_rest) in
    Obj.repr(
# 78 "parser.mly"
                                        ( Call(_1, _3::_4))
# 570 "parser.ml"
               : Ast.expr))
; (fun __caml_parser_env ->
    Obj.repr(
# 80 "parser.mly"
                                        ( [] )
# 576 "parser.ml"
               : 'expr_rest))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr_rest) in
    Obj.repr(
# 81 "parser.mly"
                                        ( _2 :: _3)
# 584 "parser.ml"
               : 'expr_rest))
; (fun __caml_parser_env ->
    Obj.repr(
# 83 "parser.mly"
                                        ( TUnit )
# 590 "parser.ml"
               : 'typ))
; (fun __caml_parser_env ->
    Obj.repr(
# 84 "parser.mly"
                                        ( TBool )
# 596 "parser.ml"
               : 'typ))
; (fun __caml_parser_env ->
    Obj.repr(
# 85 "parser.mly"
                                        ( TInt )
# 602 "parser.ml"
               : 'typ))
; (fun __caml_parser_env ->
    Obj.repr(
# 86 "parser.mly"
                                        ( TArr )
# 608 "parser.ml"
               : 'typ))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'expr_list) in
    Obj.repr(
# 88 "parser.mly"
                                        ( Seq _2 )
# 615 "parser.ml"
               : 'seq))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 90 "parser.mly"
                                        ( [_1] )
# 622 "parser.ml"
               : 'expr_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr_list) in
    Obj.repr(
# 91 "parser.mly"
                                        ( _1 :: _3 )
# 630 "parser.ml"
               : 'expr_list))
; (fun __caml_parser_env ->
    Obj.repr(
# 93 "parser.mly"
                                        ( CUnit )
# 636 "parser.ml"
               : 'const))
; (fun __caml_parser_env ->
    Obj.repr(
# 94 "parser.mly"
                                        ( CBool(true) )
# 642 "parser.ml"
               : 'const))
; (fun __caml_parser_env ->
    Obj.repr(
# 95 "parser.mly"
                                        ( CBool(false) )
# 648 "parser.ml"
               : 'const))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 96 "parser.mly"
                                        ( CInt(_1) )
# 655 "parser.ml"
               : 'const))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 98 "parser.mly"
                                        ( Unary(Not, _2) )
# 662 "parser.ml"
               : 'unop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 100 "parser.mly"
                                        ( Binary(Add, _1, _3) )
# 670 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 101 "parser.mly"
                                        ( Binary(Sub, _1, _3) )
# 678 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 102 "parser.mly"
                                        ( Binary(Mul, _1, _3) )
# 686 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 103 "parser.mly"
                                        ( Binary(Div, _1, _3) )
# 694 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 104 "parser.mly"
                                        ( Binary(Eq, _1, _3) )
# 702 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 105 "parser.mly"
                                        ( Binary(Neq, _1, _3) )
# 710 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 106 "parser.mly"
                                        ( Binary(Gt, _1, _3) )
# 718 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 107 "parser.mly"
                                        ( Binary(Geq, _1, _3) )
# 726 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 108 "parser.mly"
                                        ( Binary(Lt, _1, _3) )
# 734 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 109 "parser.mly"
                                        ( Binary(Leq, _1, _3) )
# 742 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 110 "parser.mly"
                                        ( Binary(And, _1, _3) )
# 750 "parser.ml"
               : 'binop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : Ast.expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : Ast.expr) in
    Obj.repr(
# 111 "parser.mly"
                                        ( Binary(Or, _1, _3) )
# 758 "parser.ml"
               : 'binop))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry expr *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Ast.prog)
let expr (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 2 lexfun lexbuf : Ast.expr)

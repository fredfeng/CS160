#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int patina_expr();
int main() {
  printf(">>> Output >>>\n");
  int n = patina_expr();
  printf("<<< Output <<<\n");
  printf("Result: %d\n", n);
  return 0;
}

void print_ln() {
  printf("\n");
}

void print_int(int64_t n) {
  printf("%lld", n);
}

void print_bool(int64_t n) {
  if (n) {
    printf("true");
  } else {
    printf("false");
  }
}

void print_arr(int64_t* arr, int64_t len) {
  for (int64_t i = 0; i < len; i++) {
    if (i > 0) {
      printf(" ");
    }
    printf("%lld", arr[i]);
  }
}

int64_t* alloc(int64_t len) {
  return calloc((size_t) len, sizeof(int64_t));
}
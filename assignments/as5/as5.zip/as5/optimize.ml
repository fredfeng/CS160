open Front_end
open Ast

let impossible () = failwith "Impossible"
let hole () = failwith "TODO"

(* Environment *)
type env = (string * bottom) list
and  bottom = |

let lookup k env = List.assoc_opt k env
let insert k v env = (k,v) :: env

(* Constant folding and propagation *)
let rec fold_constant (e: expr) (env: env) : env * expr = 
  let recur e = fold_constant e env |> snd in
  let return e = (env, e) in
  match e with
  | Const _ -> hole ()
  | Id x -> hole ()
  | Let (x, t, rhs) -> hole ()
  | Seq es -> hole ()
  | Unary (op, e') -> hole ()
  | Binary (op, e1, e2) -> hole ()
  | Ite (ec, et, ef) -> hole ()
  | Call (f, args) -> hole ()
  | _ -> return e

and optimize_expr (e: expr) (env: env) : expr =
  (* fix f computes the fixpoint of function f *)
  let rec fix (f: 'a -> 'a) (x: 'a) (i: int): 'a =
    Printf.printf "Iteration %d\n%!" i;
    let x' = f x in
    if x = x' then x' else fix f x' (i+1) in
  (* feel free to add more optimization phases, e.g. dead code elimination *)
  let fold_once e = fold_constant e env |> snd in
  fix fold_once e 0

let optimize_fn (f: fn) : fn =
  let {name; param; body; return} = f in
  let env = hole () in
  let body' = optimize_expr body env in
  {name = name; param = param; body = body'; return = return}

let optimize_prog (p: prog) : prog =
  List.map optimize_fn p